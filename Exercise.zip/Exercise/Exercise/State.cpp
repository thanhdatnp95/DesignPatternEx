#include "State.h"

State::State(list<Shape*>* lstShape)
{
    this->numOfCircle = 0;
    this->numOfRectangle = 0;

    this->lstShape = lstShape;
}

State::~State()
{
    for each (Shape* shape in *lstShape)
    {
        delete shape;
    }

    delete lstShape;
}

list<Shape*>* State::getLstShape()
{
    return this->lstShape;
}

int State::getNumOfCircle()
{
    return this->numOfCircle;
}

void State::setNumOfCircle(int num)
{
    this->numOfCircle = num;
}

int State::getNumOfRectangle()
{
    return this->numOfRectangle;
}

void State::setNumOfRectangle(int num)
{
    this->numOfRectangle = num;
}