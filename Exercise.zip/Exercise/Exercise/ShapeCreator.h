#ifndef SHAPECREATOR_H
#define SHAPECREATOR_H

#include <iostream>
#include "Circle.h"
#include "Rectangle.h"

//Singleton & Factory class
class ShapeCreator
{
private:
    ShapeCreator();

public:
    ShapeCreator(ShapeCreator const&) = delete;
    void operator=(ShapeCreator const&) = delete;

    Shape* createShape(const char*, double a = 0, double b = 0);

    static ShapeCreator& getCreator();
};

#endif // !SHAPECREATOR_H
