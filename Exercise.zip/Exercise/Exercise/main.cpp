#include "ShapeCreator.h"
#include "State.h"
#include <list>
using namespace std;

int main()
{
    list<State*> lstState;

    for each (State* state in lstState)
    {
        delete state;
    }
    system("pause");
    return 0;
}