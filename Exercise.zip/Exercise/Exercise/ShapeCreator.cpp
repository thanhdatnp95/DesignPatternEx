#include "ShapeCreator.h"

ShapeCreator& ShapeCreator::getCreator()
{
    static ShapeCreator creator;
    return creator;
}
Shape* ShapeCreator::createShape(const char* type, double a, double b)
{
    if (type == "CIRCLE")
    {
        return new Circle(a);
    }
    else if (type == "RECTANGLE")
    {
        return new Rectangle(a, b);
    }
    else
        return NULL;
}