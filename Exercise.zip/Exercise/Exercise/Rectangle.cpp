#include "Rectangle.h"

Rectangle::Rectangle(double height, double width)
{
    this->height = height;
    this->width = width;
}

double Rectangle::getHeight()
{
    return this->height;
}
void Rectangle::setHeight(double height)
{
    this->height = height;
}
double Rectangle::getWidth()
{
    return this->width;
}
void Rectangle::setWidth(double width)
{
    this->width = width;
}

void Rectangle::draw()
{

}