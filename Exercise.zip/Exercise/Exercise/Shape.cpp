#include "Shape.h"

Shape::Shape()
{
    this->position = new int[DIMENSION] {0, 0};
}

int* Shape::getPosition()
{
    return this->position;
}

void Shape::setPosition(int x, int y)
{
    this->position[0] = x;
    this->position[1] = y;
}