#include "Circle.h"

Circle::Circle(double radius)
{
    this->radius = radius;
}

double Circle::getRadius()
{
    return this->radius;
}

void Circle::setRadius(double radius)
{
    this->radius = radius;
}

void Circle::draw()
{

}