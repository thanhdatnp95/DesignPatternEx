#ifndef SHAPE_H
#define SHAPE_H

#define        DIMENSION        2

class Shape
{
protected:
    int* position;

public:
    Shape();
    int* getPosition();
    void setPosition(int, int);    
    virtual void draw();
};

#endif // !SHAPE_H


