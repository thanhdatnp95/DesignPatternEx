#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Shape.h"

class Rectangle : public Shape
{
private:
    double height;
    double width;

public:
    Rectangle(double, double);
    double getHeight();
    void setHeight(double);
    double getWidth();
    void setWidth(double);
    void draw();
};

#endif // !RECTANGLE_H
