#ifndef STATE_H
#define STATE_H

#include <list>
#include "Shape.h"
using namespace std;

class State
{
private:
    int numOfCircle;
    int numOfRectangle;

    list<Shape*>* lstShape;

public:
    State(list<Shape*>*);
    ~State();

    list<Shape*>* getLstShape();
    int getNumOfCircle();
    void setNumOfCircle(int);
    int getNumOfRectangle();
    void setNumOfRectangle(int);
};

#endif // !STATE_H

